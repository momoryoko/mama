<?php
date_default_timezone_set('Asia/Jakarta');
@system("clear");
    $senxx = "utm";
$urutann = file_get_contents("$senxx");
$yelahh = explode("\n",$urutann);
while(true){
for($x=0;$x<count($yelahh);$x++){
$yeah = explode("|",$yelahh[$x]);
$crot = $yeah[0];
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://digitask.ru/notimer/faucet.php?address=".$crot."&g-recaptcha-response=03AERD8XqMCqLsNtYh81sS37BR7tkPy1heBC10_M6tpY0u3C3RWI_jfEfGYagUMUCBbQ085cXtFL3UWTWsqR7xsEyFmGD-cuYY82aQ4SgxI6mxpPsZ_200jbyyIOqgNdXhI0Z3j4mfj2cRAiPxRiSzEw_1x-QYxTxk-MyBRwmHBSiCBsWqz20iOKF_P-ylPJitty-eUKs35IJDYFDGeuI2bSQZjtYmy6nN-vtQOSlMTxIyd3BMZhvYJ7FfzZwOoGEmzmBhDWLV-GsNvMYzz977fW2JZPWkuXZAXvVBYcPrFSTuRzOA0hHehElCgqYPj-W0lVTqatzOv7wawbPpc1cpap1btFhtmXSVd3qTqycGHDltR4fXQi-0RT8ByIR0d-S3hl6Rug8vfYX0&wallet=&currency=DOGE&key=c2e5fc98b99646f64b1fa886fb632efe");
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_POST, "GET");
curl_setopt($ch, CURLOPT_HTTPHEADER, array("Host: digitask.ru" , "upgrade-insecure-requests: 1" , "user-agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.92 Safari/537.36"  , "accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3" , "referer: https://digitask.ru/notimer/" , "accept-language: id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7" , "cookie: valet_adress=".$crot."" , "cookie: ft=2447280213" , "cookie: valet_adress=".$crot."" , "cookie: bidswitch_last_time=1583257103973" , "cookie: rekmob_props_551290=%7B%22date%22%3A1583279759579%2C%22rekJs%22%3A%7B%22rekmob_ad_unit_type%22%3A1%2C%22rekmob_native_type%22%3Anull%2C%22rekmob_ad_width%22%3A300%2C%22rekmob_fixed_cpm%22%3A0%2C%22rekmob_network_ids%22%3A%22imdi_placement_id%3D22064433%3Bcrt_id%3D0%22%2C%22rekmob_ad_unit%22%3A%2209010173e50d4a559c86fadfbafa3797%22%2C%22rekmob_app_type%22%3A1%2C%22rekmob_ad_height%22%3A250%2C%22region_id%22%3A551290%7D%2C%22countryCode%22%3A%22ID%22%2C%22cookieTime%22%3A1583280212317%7D" , "cookie: rekmob_props_591630=%7B%22date%22%3A1583279941357%2C%22rekJs%22%3A%7B%22rekmob_ad_unit_type%22%3A1%2C%22rekmob_native_type%22%3Anull%2C%22rekmob_ad_width%22%3A300%2C%22rekmob_fixed_cpm%22%3A0%2C%22rekmob_network_ids%22%3A%22crt_id%3D0%22%2C%22rekmob_ad_unit%22%3A%22c7384edf01d64edd88a1443cf301fefd%22%2C%22rekmob_app_type%22%3A1%2C%22rekmob_ad_height%22%3A250%2C%22region_id%22%3A591630%7D%2C%22countryCode%22%3A%22ID%22%2C%22cookieTime%22%3A1583280197546%7D" , "cookie: rekmob_props_551290=%7B%22date%22%3A1583279759579%2C%22rekJs%22%3A%7B%22rekmob_ad_unit_type%22%3A1%2C%22rekmob_native_type%22%3Anull%2C%22rekmob_ad_width%22%3A300%2C%22rekmob_fixed_cpm%22%3A0%2C%22rekmob_network_ids%22%3A%22imdi_placement_id%3D22064433%3Bcrt_id%3D0%22%2C%22rekmob_ad_unit%22%3A%2209010173e50d4a559c86fadfbafa3797%22%2C%22rekmob_app_type%22%3A1%2C%22rekmob_ad_height%22%3A250%2C%22region_id%22%3A551290%7D%2C%22countryCode%22%3A%22ID%22%2C%22cookieTime%22%3A1583280212317%7D" , "cookie: address=D5mx6oZUm5ciACzzX3bzY3qruqH6icPkD9" , "cookie: rekmob_last_seen_09010173e50d4a559c86fadfbafa3797=1583280395252" , "cookie: _data_cpc=15-2_17-1_18-2" , "cookie: rekmob_props_547047=%7B%22date%22%3A1583279901784%2C%22rekJs%22%3A%7B%22rekmob_ad_unit_type%22%3A3%2C%22rekmob_native_type%22%3Anull%2C%22rekmob_ad_width%22%3A728%2C%22rekmob_fixed_cpm%22%3A0%2C%22rekmob_network_ids%22%3A%22imdi_placement_id%3D22042045%3Bcrt_id%3D0%22%2C%22rekmob_ad_unit%22%3A%22dd0f6bb180c64d898171986d1aea58e2%22%2C%22rekmob_app_type%22%3A1%2C%22rekmob_ad_height%22%3A90%2C%22region_id%22%3A547047%7D%2C%22countryCode%22%3A%22ID%22%2C%22cookieTime%22%3A1583280212258%7D" , "cookie: rekmob_last_seen_dd0f6bb180c64d898171986d1aea58e2=1583280394807" , "cookie: rekmob_last_seen_1f2b0bf06f9e40baa5ad6fac7f27c007=1583280395303" , "cookie: rekmob_last_seen_c7384edf01d64edd88a1443cf301fefd=1583280394383" , "cookie: rekmob_props_547149=%7B%22date%22%3A1583280138151%2C%22rekJs%22%3A%7B%22rekmob_ad_unit_type%22%3A1%2C%22rekmob_native_type%22%3Anull%2C%22rekmob_ad_width%22%3A300%2C%22rekmob_fixed_cpm%22%3A0%2C%22rekmob_network_ids%22%3A%22imdi_placement_id%3D22042046%3Bcrt_id%3D0%22%2C%22rekmob_ad_unit%22%3A%22df7c16a7098a4b5881b72703eef7cd0c%22%2C%22rekmob_app_type%22%3A1%2C%22rekmob_ad_height%22%3A250%2C%22region_id%22%3A547149%7D%2C%22countryCode%22%3A%22ID%22%2C%22cookieTime%22%3A1583284386457%7D" , "cookie: rekmob_last_seen_09010173e50d4a559c86fadfbafa3797=1583280395252"));
curl_setopt($ch, CURLOPT_COOKIEJAR, "ck");
curl_setopt($ch, CURLOPT_COOKIEFILE, "ck");
$mbot = curl_exec($ch);
curl_close($ch);
$bale = explode('<div class="alert alert-success">', $mbot);
$bale2 = explode('<a target=',$bale[1]);
$xc = $bale2[0];
$pet1 = explode('<p><i class="fa fa-exclamation-triangle fa-2x" style="color:#FF8C00"></i>', $mbot);
$pet12 = explode('</p>',$pet1[1]);
$pet = $pet12[0];

if($xc == true){
echo " \033[1;33m[\033[1;35m".date('H:i:s')."\033[1;33m] \e[0m# \033[1;36m".$xc."your account".$x."\n";
}
}
}